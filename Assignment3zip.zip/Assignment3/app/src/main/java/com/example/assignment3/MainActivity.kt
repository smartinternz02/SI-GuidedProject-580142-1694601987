package com.example.assignment3

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val username: EditText = findViewById(R.id.etUsername)
        var password: EditText = findViewById(R.id.etPassword)
        var radioGroup :RadioGroup =findViewById(R.id.rg1)
        var btnsubmit: Button = findViewById(R.id.btnOpen)

        btnsubmit.setOnClickListener {


                // Getting the checked radio button id
                // from the radio group

                val selectedOption: Int = radioGroup!!.checkedRadioButtonId

                // Assigning id of the checked radio button
                var RadioButton:RadioButton = findViewById(selectedOption)

                // assigning url of the checked radio button
                val url = when(RadioButton.id.toString())
            {
                "2131231219" -> "http://www.amazon.in"
                "2131231220" -> "http://www.flipkart.com"
                "2131231221" -> "http://www.myntra.com"
                else -> ""
            }
            //opening a url
            val i = Intent(Intent.ACTION_VIEW)
            i.data = Uri.parse(url)
            startActivity(i)


        }
    }

}